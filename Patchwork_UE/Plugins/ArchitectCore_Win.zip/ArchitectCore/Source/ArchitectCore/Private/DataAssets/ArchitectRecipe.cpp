// Fill out your copyright notice in the Description page of Project Settings.


#include "DataAssets/ArchitectRecipe.h"

void UArchitectRecipe::AutoCalculateFootprint()
{
	//if (IsValid(Wall.StaticMesh))
	//{
	//	//FVector size = Wall.StaticMesh.Get()->GetBoundingBox().GetSize();
	//	//Footprint = size;
	//}
}
