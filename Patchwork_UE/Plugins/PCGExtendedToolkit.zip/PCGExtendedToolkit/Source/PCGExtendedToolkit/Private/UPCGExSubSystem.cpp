﻿// Copyright Timothé Lapetite 2024
// Released under the MIT license https://opensource.org/license/MIT/

#include "UPCGExSubSystem.h"

void UPCGExSubSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	// Initialization code
}

void UPCGExSubSystem::Deinitialize()
{
	Super::Deinitialize();
	// Cleanup code
}
