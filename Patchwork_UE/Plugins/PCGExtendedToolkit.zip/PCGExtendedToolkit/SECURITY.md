# Security Policy

This is a plugin for Unreal Engine which has its own security fail safes; some diagnostics are run automatically by git as well as FAB when updates are pushed to the marketplace.  
I don't know of any additional security measures I can take : integration of third parties to the repo is prohibited.
